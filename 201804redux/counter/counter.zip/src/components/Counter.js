import React from 'react';
import ReactDOM from 'react-dom';
import actions from '../store/actions/counter';
import store from '../store';
import { bindActionCreator } from '../redux';
//它的作用是把actionCreator和store.dispatch绑在一起
let newActions = bindActionCreator(actions, store.dispatch);
export default class Counter extends React.Component {
    state = { number: store.getState().counter.number, num: 0 };
    componentWillMount() {
        //订阅状态变化事件，当状态发生变化的时候修改当前组件的状态，然后会更新渲染组件
        this.unsubcribe = store.subscribe(() => {
            this.setState({ number: store.getState().counter.number });
        });
    }
    //当组件将要销毁的时候要取消订阅
    componentWillUnmount() {
        this.unsubcribe();
    }
    kill = () => {
        ReactDOM.unmountComponentAtNode(document.querySelector('#root'));
    }
    render() {
        return (
            <div>
                <p>{this.state.number}</p>
                <button onClick={() => newActions.add(1)}>+</button>
                <button onClick={() => newActions.minus(2)}>-</button>
            </div>
        )
    }
}
