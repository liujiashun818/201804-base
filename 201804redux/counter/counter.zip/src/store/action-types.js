export const ADD = 'ADD';
export const MINUS = 'MINUS';


export const ADD2 = 'ADD2';
export const MINUS2 = 'MINUS2';